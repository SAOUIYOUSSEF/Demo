package com.example.demo;

import com.example.demo.entities.Creator;
import com.example.demo.entities.Video;
import com.example.demo.repository.CreatorRepository;
import com.example.demo.repository.VideoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@SpringBootApplication
public class Tp01Application {
    public List<Video>videos;
    @Autowired
    private CreatorRepository creatorRepository;
    @Autowired
    private VideoRepository videoRepository;


    public static void main(String[] args) {
        SpringApplication.run(Tp01Application.class, args);
    }
    @Bean
    CommandLineRunner start()
    {
        return args -> {
            Creator creator = Creator.builder()
                    .name("zrida soufiane")
                    .email("zrida109@gmail.com")
                    .build();
            Creator creator1 = Creator.builder()
                    .name("Yassine EL MANIARI")
                    .email("yassineelmaniari@gmail.com")
                    .build();
            Creator creator2 = Creator.builder()
                    .name("toto")
                    .email("toto@gmail.com")
                    .build();
            Creator creator3 = Creator.builder()
                    .name("ayoube")
                    .email("ayoube@gmail.com")
                    .build();
            Video v =  Video.builder()
                    .name("soufianeVideo")
                    .url("http://soufianevideo.com")
                    .description("Il s'agit d'un video sur l'IA")
                    .datePublication(new Date())
                    .creator(creator)
                    .build();
            Video v1= Video.builder()
                    .name("YassineVideo")
                    .url("http://yassinevideo.com")
                    .description("Il s'agit d'un video sur l'IA")
                    .datePublication(new Date())
                    .creator(creator)
                    .build();
            Video v2 =  Video.builder()
                    .name("ayoubeVideo")
                    .url("http://ayoubevideo.com")
                    .description("Il s'agit d'un video sur l'IA")
                    .datePublication(new Date())
                    .creator(creator3)
                    .build();
            Video v3 = Video.builder()
                    .name("HishamVideo")
                    .url("http://hishamvideo.com")
                    .description("Il s'agit d'un video sur l'IA")
                    .datePublication(new Date())
                    .creator(creator2)
                    .build();
            Video v4 =  Video.builder()
                    .name("WafaaVideo")
                    .url("http://wafaavideo.com")
                    .description("Il s'agit d'un video sur l'IA")
                    .datePublication(new Date())
                    .creator(creator1)
                    .build();
            Video v5 = Video.builder()
                    .name("ChaimaaVideo")
                    .url("http://chaimaavideo.com")
                    .description("Il s'agit d'un video sur l'IA")
                    .datePublication(new Date())
                    .creator(creator)
                    .build();
            videos = new ArrayList<>();
            videos.add(v);
            videos.add(v1);
            videos.add(v2);
            videos.add(v3);
            videos.add(v4);
            videos.add(v5);
            creator.setVideos(videos);
            creatorRepository.save(creator);
            creatorRepository.save(creator1);
            creatorRepository.save(creator2);
            creatorRepository.save(creator3);
            videoRepository.save(v);
            videoRepository.save(v1);
            videoRepository.save(v2);
            videoRepository.save(v3);
            videoRepository.save(v4);
            videoRepository.save(v5);
        };
    }

}