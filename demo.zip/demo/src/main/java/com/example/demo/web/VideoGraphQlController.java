package com.example.demo.web;

import com.example.demo.entities.Creator;
import com.example.demo.entities.Video;
import com.example.demo.repository.CreatorRepository;
import com.example.demo.repository.VideoRepository;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class VideoGraphQlController {
    private CreatorRepository creatorRepository;
        private VideoRepository videoRepository;
        VideoGraphQlController(CreatorRepository creatorRepository, VideoRepository videoRepository){
            this.creatorRepository = creatorRepository;
            this.videoRepository = videoRepository;
        }
        @QueryMapping
        public List<Video> videoList(){
            return videoRepository.findAll();
        }
        @QueryMapping
        public Creator creatorById(@Argument Long id) {
            return creatorRepository.findById(id)
                    .orElseThrow(()->new RuntimeException(String.format("Creator %s not found",id)));
        }
    @MutationMapping
    public Creator saveCreator(@Argument Creator creator){
        return creatorRepository.save(creator) ;
    }
    @MutationMapping
    public Video saveVideo(@Argument Video video){
        return videoRepository.save(video) ;
    }


}
